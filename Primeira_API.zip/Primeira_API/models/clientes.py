from database.db import db
from sqlalchemy import ForeignKey
from sqlalchemy.orm import relationship


class clientes(db.Model):
    def to_dict(self):
        return{
            'name': self.name,
            'email': self.email,
            'cargo_id':self.cargo_id
        }

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    email = db.Column(db.String(100))
    cargo_id = db.Column(ForeignKey('cargos.id'))
    
    cargo = relationship('Cargos', backref='clientes')

    def __init__(self, name, email, cargo_id):
        self.name = name
        self.email = email
        self.cargo_id = cargo_id