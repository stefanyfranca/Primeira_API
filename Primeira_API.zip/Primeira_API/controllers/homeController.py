from flask import render_template
from models.clientes import clientes

def homeController():
        user = clientes("rodrigo", "rodrigo456@gmail.com")
        return render_template('index.html', user=user)